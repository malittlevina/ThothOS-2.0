# Bridge to symbolic memory engine (stub)
