# Bridge to StoryRealms runtime (stub)
