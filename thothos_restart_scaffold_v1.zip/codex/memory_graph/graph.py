# codex/memory_graph/graph.py (stub)
class MemoryGraph:
    def __init__(self):
        self.nodes = {}
        self.edges = []

    def add(self, node_id, data):
        self.nodes[node_id] = data
