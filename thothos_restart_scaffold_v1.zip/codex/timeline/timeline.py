# codex/timeline/timeline.py (stub)
def record(event_type: str, payload: dict):
    # TODO: persist to storage
    return {"ok": True, "event_type": event_type, "payload": payload}
